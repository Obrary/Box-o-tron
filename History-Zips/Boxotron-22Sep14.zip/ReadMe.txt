Product: Box-o-tron, September 2014

Designer: Simon Kirkby

Support:  http://forums.obrary.com/category/designs/box-o-tron

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary is a marketplace of products collaboratively designed by the community. These products can be produced by anyone, amateur or professional manufacturer, wherever economically or locally practical.

Description:
Make a box of dimensions that you specify using this Python app.